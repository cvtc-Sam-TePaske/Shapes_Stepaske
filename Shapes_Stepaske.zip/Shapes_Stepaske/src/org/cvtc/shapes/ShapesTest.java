//Package
package org.cvtc.shapes;

//Imports
import javax.swing.JOptionPane;

/**
 * @author Sam TePaske
 */
public class ShapesTest {
	/**
	 * @param args
	 */
	//Main method
	public static void main(String[] args) {
		//Create the shapes
		Cuboid cube = new Cuboid();
		Cylinder cylinder = new Cylinder();
		Sphere sphere = new Sphere();

		//Set and validate cube dimensions. Dimensions will be validated for negative number input. 
		while(cube.getDepth() <=0 || cube.getLength() <= 0|| cube.getWidth() <= 0) {
			cube.setDepth(Float.valueOf(JOptionPane.showInputDialog("Cube Depth: ")));
			cube.setLength(Float.valueOf(JOptionPane.showInputDialog("Cube Length: ")));
			cube.setWidth(Float.valueOf(JOptionPane.showInputDialog("Cube Width: "))); 
		}

		//Set cylinder dimensions. Dimensions will be validated for negative number input.
		while(cylinder.getHeight() <=0 || cylinder.getRadius() <= 0) {
			cylinder.setHeight(Float.valueOf(JOptionPane.showInputDialog("Cylinder Height: ")));
			cylinder.setRadius(Float.valueOf(JOptionPane.showInputDialog("Cylinder Radius: ")));
		}

		//Set sphere dimensions. Dimensions will be validated for negative number input.
		while(sphere.getRadius() <=0) {
			sphere.setRadius(Float.valueOf(JOptionPane.showInputDialog("Sphere Radius:: ")));
		}
		//Implement the renders, display the calculations. The message for the output is passed in String format to the respective class's method.
		cube.render("--Cube--" +"\n" + "Surface Area: " + Float.toString(cube.surfaceArea()) + "\n" + "Volume: " + Float.toString(cube.volume()));
		cylinder.render("--Cylinder--" +"\n" + "Surface Area: " + Float.toString(cylinder.surfaceArea()) + "\n" + "Volume: " + Float.toString(cylinder.volume()));
		sphere.render("--Sphere--" +"\n" + "Surface Area: " + Float.toString(sphere.surfaceArea()) + "\n" + "Volume: " + Float.toString(sphere.volume()));

	}

}
