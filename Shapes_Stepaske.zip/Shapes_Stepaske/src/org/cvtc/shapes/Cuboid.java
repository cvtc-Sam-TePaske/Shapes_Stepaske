//Package
package org.cvtc.shapes;

//Import
import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * @author Sam TePaske
 */
public class Cuboid extends Shape {

	//Private frame component for render()
	private Component frame;

	//Constructor
	public Cuboid() {
		this.length = 0;
		this.width = 0;
		this.depth = 0;
	}

	//Attributes
	private float length;
	private float width;
	private float depth;

	//Getter and Setter Methods
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}

	public float getDepth() {
		return depth;
	}
	public void setDepth(float depth) {
		this.depth = depth;
	}

	//Utilizing the Abstract methods from the Shape.java super class
	@Override
	public float surfaceArea() {
		//Area = 2 x width x length + 2 x length x height + 2 x height x width
		return (float) (2 * (width * length) + (2 * (length * depth)) + (2 * (depth * width)) );
	}
	@Override
	public void render(String message) {
		JOptionPane.showMessageDialog(frame, message);

	}
	@Override
	public float volume() {
		// TODO Auto-generated method stub
		return (float) (length * width * depth);
	}

}
