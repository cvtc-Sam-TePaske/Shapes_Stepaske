//Package
package org.cvtc.shapes;

//Import statements
import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * @author Sam TePaske
 */
public class Cylinder extends Shape {

	//Private frame component for render()
	private Component frame;

	public Cylinder() {
		this.height = (float) 0.0;
		this.radius = (float) 0.0;
	}

	//Attributes
	private float height;
	private float radius;

	//Getter and Setter Methods
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}

	//Utilizing the Abstract methods from the Shape.java super class
	@Override
	public float surfaceArea() {
		//Surface Area of a Cylinder 2*pi*r(h+r)
		return (float) (2*Math.PI*radius*(height+radius));
	}
	@Override
	public void render(String message) {
		JOptionPane.showMessageDialog(frame, message);

	}
	@Override
	public float volume() {
		//Volume of a Cylinder pi*r^2*h
		return (float) (height * Math.PI * Math.pow(radius, 2));
	}

}
