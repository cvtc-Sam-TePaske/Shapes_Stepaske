//Package
package org.cvtc.shapes;

//Import Statements
import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * @author Sam TePaske
 */
public class Sphere extends Shape {
	
	//Private frame component for render()
	private Component frame;
	
	//Attributes
	private float radius;

	//Constructor
	public Sphere() {
		this.radius = (float) 0.0;
	}
	
	//Getter and Setter Methods
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	//Utilizing the Abstract methods from the Shape.java super class
	@Override
	public float surfaceArea() {
		//Surface Area formula for Spheres 4 pi r^2
		return  (float) (4 * Math.PI * Math.pow(radius, 2));
	}
	@Override
	public void render(String message) {
		JOptionPane.showMessageDialog(frame, message);
		
	}
	@Override
	public float volume() {
		//Volume formula for Sphere 4/3*pi*r^3
		return (float) (4.0/3 * Math.PI * Math.pow(radius, 3));
	
	}
}
