//Package
package org.cvtc.shapes;

/**
 * @author Sam TePaske
 */
public abstract class Shape {
	//Abstract Surface Area method
	public abstract float surfaceArea();
	
	//Abstract Render method
	public abstract void render(String message);

	//Abstract Volume method
	public abstract float volume();
	
}
