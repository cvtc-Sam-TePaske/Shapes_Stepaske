/**
 * 
 */
/**
 * @author Neet
 *
 */
module shapes {
	requires java.desktop;
}